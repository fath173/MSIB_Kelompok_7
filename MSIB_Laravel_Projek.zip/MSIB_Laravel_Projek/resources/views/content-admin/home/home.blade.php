@extends('content-admin.index')
@section('isi-contentAdmin')
    @include('content-admin.home.content')
    {{-- {{ $data }} --}}
@endsection
