<script src="{{ asset('assets/landing/js/jquery-3.2.1.min.js') }}"></script>
<script src="{{ asset('assets/landing/styles/bootstrap4/popper.js') }}"></script>
<script src="{{ asset('assets/landing/styles/bootstrap4/bootstrap.min.js') }}"></script>
<script src="{{ asset('assets/landing/plugins/OwlCarousel2-2.2.1/owl.carousel.js') }}"></script>
<script src="{{ asset('assets/landing/plugins/easing/easing.js') }}"></script>
<script src="{{ asset('assets/landing/plugins/parallax-js-master/parallax.min.js') }}"></script>
<script src="{{ asset('assets/landing/js/custom.js') }}"></script>
