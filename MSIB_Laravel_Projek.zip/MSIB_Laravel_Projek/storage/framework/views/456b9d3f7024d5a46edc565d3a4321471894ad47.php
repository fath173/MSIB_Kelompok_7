<!-- Large Modal -->
<div class="modal fade" id="detail<?php echo e($user->id); ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel3">Update Petugas</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('admin-petugas-update',$user->id)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <!-- <?php echo method_field('POST'); ?> -->
                <div class="modal-body">
                    <div class="row g-2 mb-3">
                        <div class="col mb-0">
                            <label for="dobLarge" class="form-label">Nama</label>
                            <input type="text" id="dobLarge" name="name" class="form-control" value="<?php echo e($user->name); ?>" placeholder="Tulis Nama" />
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col mb-0">
                            <label for="select1" class="form-label">Gender</label>
                            <select class="form-select" name="gender" id="select1" aria-label="Default select example">
                                <?php if($user->gender == 'L'): ?>
                                <option value="L" selected>Laki-laki</option>
                                <option value="P">Perempuan</option>
                                <?php else: ?>
                                <option value="L">Laki-laki</option>
                                <option value="P" selected>Perempuan</option>
                                <?php endif; ?>
                            </select>
                        </div>
                        <div class="col mb-0">
                            <label for="select2" class="form-label">Role</label>
                            <select class="form-select" name="role" id="select2" aria-label="Default select example">
                                <?php if($user->role == 'admin'): ?>
                                <option value="admin" selected>Admin</option>
                                <option value="petugas">Petugas</option>
                                <?php else: ?>
                                <option value="admin">Admin</option>
                                <option value="petugas" selected>Petugas</option>
                                <?php endif; ?>
                            </select>
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col mb-0">
                            <label for="dobLarge" class="form-label">Email</label>
                            <input type="email" id="dobLarge" name="email" class="form-control" value="<?php echo e($user->email); ?>" placeholder="Tulis Email" />
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col mb-0">
                            <label for="dobLarge" class="form-label">Password</label>
                            <input type="text" id="dobLarge" name="password" class="form-control" onfocus="this.type='password'" onblur="if(this.value == '<?php echo e($user->password); ?>')this.type='text'" value="<?php echo e($user->password); ?>" placeholder="Tulis Password" />
                        </div>
                    </div>

                    <div class="row g-2 mb-3">
                        <div class="col mb-0">
                            <label for="dobLarge" class="form-label">Upload gambar</label>
                            <input type="file" id="dobLarge" name="foto" class="form-control" accept=".png, .jpg, .jpeg" placeholder="upload gambar" />
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button type="submit" value="ubah" class="btn btn-primary"> Update </button>
                    <!-- <input type="hidden" name="idx" value="<?php echo e($user->id); ?>"> -->
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\MSIB_Kelompok_7\MSIB_Laravel_Projek\resources\views/content-admin/petugas/edit.blade.php ENDPATH**/ ?>