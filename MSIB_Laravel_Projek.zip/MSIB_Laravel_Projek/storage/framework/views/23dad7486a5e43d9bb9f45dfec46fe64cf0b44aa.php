
<?php $__env->startPush('style-custom'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/landing/styles/about.css')); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/landing/styles/about_responsive.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('isi-contentLanding'); ?>
    
    <?php echo $__env->make('content-landing.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- About -->

    <div class="about">
        <div class="container">
            <div class="row">

                <!-- About Content -->
                <div class="col-lg-8">
                    <div class="section_title">
                        <h2>Apa itu VaksinMed??</h2>
                    </div>
                    <div class="about_text">
                        <p style="text-align: justify">VaksinMed merupakan suatu website untuk membantu pendataan vaksin pada masyarakat desa.
                        Pada tahap awal, vaksinasi Covid-19 sudah berhasil diberikan kepada seluruh tenaga kesahatan, asisten tenaga kesehatan,
                        dan mahasiswa yang menjalankan pendidikan profesi kedokteran yang bekerja pada fasilitas pelayanan kesehatan.
                        Vaksin tahap kedua juga sudah diberikan kepada lansia, pekerja sektor esensial, dan guru.
                        Pemerataan vaksinasi hingga saat ini dilanjutkan untuk masyarakat umum dan terus berjalan hingga berhasil menjangkau
                        seluruh warga negara Indonesia dan warga negara asing yang bertempat tinggal di Indonesia.
                        Harapannya dengan upaya pemerataan vaksinasi ini, Indonesia dapat segera bangkit dan terbebas dari penyebaran virus Covid-19.</p>
                    </div>
                    <div class="row loaders_container">
                        <div class="col-md-3 loader_col">
                            <!-- Loader -->
                            <div class="loader" data-perc="0.75"><span>Hard Work</span></div>
                        </div>
                        <div class="col-md-3 loader_col">
                            <!-- Loader -->
                            <div class="loader" data-perc="0.95"><span>Passion</span></div>
                        </div>
                        <div class="col-md-3 loader_col">
                            <!-- Loader -->
                            <div class="loader" data-perc="0.75"><span>Hard Work</span></div>
                        </div>
                        <div class="col-md-3 loader_col">
                            <!-- Loader -->
                            <div class="loader" data-perc="0.95"><span>Passion</span></div>
                        </div>
                    </div>

                </div>

                <!-- Boxes -->
                <div class="col-lg-4 boxes_col">

                    <!-- Box -->
                    <div class="box working_hours">
                        <div class="box_icon d-flex flex-column align-items-start justify-content-center">
                            <div style="width:29px; height:29px;"><img
                                    src="<?php echo e(asset('assets/landing/images/alarm-clock.svg')); ?>" alt=""></div>
                        </div>
                        <div class="box_title">Working Hours</div>
                        <div class="working_hours_list">
                            <ul>
                                <li class="d-flex flex-row align-items-center justify-content-start">
                                    <div>Monday – Friday</div>
                                    <div class="ml-auto">8.00 – 19.00</div>
                                </li>
                                <li class="d-flex flex-row align-items-center justify-content-start">
                                    <div>Saturday</div>
                                    <div class="ml-auto">9.30 – 17.00</div>
                                </li>
                                <li class="d-flex flex-row align-items-center justify-content-start">
                                    <div>Sunday</div>
                                    <div class="ml-auto">9.30 – 15.00</div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <!-- Box -->
                    <div class="box box_appointments">
                        <div class="box_icon d-flex flex-column align-items-start justify-content-center">
                            <div style="width: 29px; height:29px;"><img
                                    src="<?php echo e(asset('assets/landing/images/phone-call.svg')); ?>" alt=""></div>
                        </div>
                        <div class="box_title">Hotline Covid-19</div>
                        <div class="box_text">Informasi panggilan darurat untuk penannganan Covid-19. Informasi lebih lanjut silahkan hubungi : 119</div>
                    </div>

                    <!-- Box -->
                    <div class="box box_emergency">
                        <div class="box_icon d-flex flex-column align-items-start justify-content-center">
                            <div style="width: 37px; height:37px; margin-left:-4px;"><img
                                    src="<?php echo e(asset('assets/landing/images/bell.svg')); ?>" alt="">
                            </div>
                        </div>
                        <div class="box_title">Narahubung</div>
                        <div class="box_emergency_text">Jika ada ingin mengetahui informasi secara lengkap, dapat langsung hubungi : 08214121231</div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script-custom'); ?>
    <script src="<?php echo e(asset('assets/landing/plugins/greensock/TweenMax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/landing/plugins/greensock/TimelineMax.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/landing/plugins/scrollmagic/ScrollMagic.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/landing/plugins/greensock/animation.gsap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/landing/plugins/greensock/ScrollToPlugin.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/landing/plugins/progressbar/progressbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/landing/js/about.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('content-landing.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MSIB_Kelompok_7\MSIB_Laravel_Projek\resources\views/content-landing/about/about.blade.php ENDPATH**/ ?>