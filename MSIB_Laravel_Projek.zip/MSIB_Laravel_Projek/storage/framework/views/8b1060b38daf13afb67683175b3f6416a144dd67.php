<h1>Anda tidak bisa akses halaman ini</h1>
<?php /**PATH C:\xampp\htdocs\MSIB_Laravel_Projek\resources\views/layouts/blank.blade.php ENDPATH**/ ?>