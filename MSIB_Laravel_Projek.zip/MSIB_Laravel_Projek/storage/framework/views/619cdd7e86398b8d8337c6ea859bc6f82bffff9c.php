<?php $__env->startSection('isi-contentAdmin'); ?>
    <h1>Ini Beranda Admin</h1>
    <?php echo e($data); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('content-admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MSIB_Laravel_Projek\resources\views/content-admin/home/home.blade.php ENDPATH**/ ?>