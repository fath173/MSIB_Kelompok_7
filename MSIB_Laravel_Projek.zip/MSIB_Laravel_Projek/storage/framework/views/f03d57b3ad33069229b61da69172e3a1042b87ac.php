<!-- Large Modal -->
<div class="modal fade" id="detail<?php echo e($jv->id); ?>" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel3">Update Jenis Vaksin</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('admin-jenis-vaksin-update', $jv->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <!-- <?php echo method_field('POST'); ?> -->
                <div class="modal-body">
                    <div class="row g-2 mb-3">
                        <div class="col mb-0">
                            <label for="dobLarge" class="form-label">Nama</label>
                            <input type="text" id="dobLarge" name="nama_vaksin" class="form-control"
                                value="<?php echo e($jv->nama_vaksin); ?>" placeholder="Tulis Nama Petugas" />
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">
                        Close
                    </button>
                    <button type="submit" value="ubah" class="btn btn-primary"> Update </button>
                    <!-- <input type="hidden" name="idx" value="<?php echo e($jv->id); ?>"> -->
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\MSIB_Kelompok_7\MSIB_Laravel_Projek\resources\views/content-admin/jenisVaksin/edit.blade.php ENDPATH**/ ?>