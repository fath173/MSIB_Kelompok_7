
<?php $__env->startSection('isi-contentAdmin'); ?>
<div class="card p-3">
    <h5 class="card-header">Petugas</h5>
    <div class="card-body">
        <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#tambah">+ Tambah
            Data</button>
        <?php echo $__env->make('content-admin.petugas.tambah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="table-responsive text-nowrap">
            <table id="datatable1" class="table">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Nama</th>
                        <th>Gender</th>
                        <th>Role</th>
                        <th>Email</th>
                        <th>Gambar</th>
                        <th>Opsi</th>
                    </tr>
                </thead>
                <tbody class="table-border-bottom-0">
                    <?php $__currentLoopData = $petugas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><strong><?= $loop->iteration ?></strong></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->gender == 'L' ? 'Laki-laki' : 'Perempuan'); ?></td>
                        <td><?php echo e($user->role); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td>
                            <img src="<?php echo e(asset('files/foto-profile/' . $user->foto)); ?>" width="50" alt="foto">
                        </td>
                        <!-- <td><?php echo e(asset('files/foto-profile/' . $user->foto)); ?></td> -->
                        </td>
                        <td>
                            <div class="d-flex">
                                <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal" data-bs-target="#detail<?php echo e($user->id); ?>">
                                    <i class="bx bx-edit-alt me-1"></i>
                                </button>
                                <?php echo $__env->make('content-admin.petugas.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                &nbsp;
                                <form method="POST" action="<?php echo e(route('admin-petugas-hapus',$user->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-sm btn-danger" type="submit" value="hapus" onclick="return confirm('Anda Yakin Data dihapus?')"><i class="bx bx-trash me-1"></i> </button>
                                    <!-- <input type="hidden" name="idx" value="<?php echo e($user->id); ?>" /> -->
                                </form>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('content-admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MSIB_Kelompok_7\MSIB_Laravel_Projek\resources\views/content-admin/petugas/petugas.blade.php ENDPATH**/ ?>