<?php $__env->startSection('isi-contentAdmin'); ?>
    <div class="card p-3">
        <h5 class="card-header">Data Kartu Keluarga</h5>
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <table id="datatable1" class="table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>No Kartu Keluarga</th>
                            <th>Anggota Keluarga</th>
                            <th>Foto KK</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $dataKK; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong><?= $loop->iteration ?></strong></td>
                                <td><?php echo e($p->no_kk); ?></td>
                                <td><?php echo e($p->pendudukFk->count()); ?> Orang</td>
                                <td>
                                    <img src="<?php echo e(asset('files/foto-kk/' . $p->foto_kk)); ?>" width="100px" alt="">
                                </td>
                                <td>
                                    <div class="d-flex">
                                        <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal"
                                            data-bs-target="#detail<?php echo e($p->id); ?>">
                                            <i class="bx bx-edit-alt me-1"></i>
                                        </button>
                                        <?php echo $__env->make('content-admin.kartuKeluarga.kk-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        &nbsp;
                                        <form method="POST" action="<?php echo e(route('admin-kkHapus', $p->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm btn-danger" type="submit"
                                                onclick="return confirm('Anda Yakin Data dihapus?')"><i
                                                    class="bx bx-trash me-1"></i> </button>
                                            <input type="hidden" name="idx" value="<?php echo e($p->id); ?>" />
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('content-admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MSIB_Kelompok_7\MSIB_Laravel_Projek\resources\views/content-admin/kartuKeluarga/kk.blade.php ENDPATH**/ ?>