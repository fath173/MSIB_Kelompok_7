<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/landing/styles/bootstrap4/bootstrap.min.css')); ?>">
<link href="<?php echo e(asset('assets/landing/plugins/font-awesome-4.7.0/css/font-awesome.min.css')); ?>" rel="stylesheet"
    type="text/css">
<link rel="stylesheet" type="text/css"
    href="<?php echo e(asset('assets/landing/plugins/OwlCarousel2-2.2.1/owl.carousel.css')); ?>">
<link rel="stylesheet" type="text/css"
    href="<?php echo e(asset('assets/landing/plugins/OwlCarousel2-2.2.1/owl.theme.default.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/landing/plugins/OwlCarousel2-2.2.1/animate.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/landing/styles/main_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/landing/styles/responsive.css')); ?>">

<link rel="stylesheet" type="text/css" href="styles/bootstrap4/bootstrap.min.css">
<link href="plugins/font-awesome-4.7.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.carousel.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/owl.theme.default.css">
<link rel="stylesheet" type="text/css" href="plugins/OwlCarousel2-2.2.1/animate.css">
<?php /**PATH C:\xampp\htdocs\MSIB_Laravel_Projek\resources\views/layouts/layout-landing/css.blade.php ENDPATH**/ ?>