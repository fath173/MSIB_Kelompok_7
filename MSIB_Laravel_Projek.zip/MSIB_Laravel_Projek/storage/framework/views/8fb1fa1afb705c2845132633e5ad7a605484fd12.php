<!DOCTYPE html>
<html lang="en">

<head>
    <title>CareMed</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="CareMed demo project">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo $__env->make('layouts.layout-landing.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('style-custom'); ?>
</head>

<body>

    <div class="super_container">

        <?php echo $__env->make('layouts.layout-landing.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->yieldContent('isi-contentLanding'); ?>
        <?php echo e(isset($slot) ? $slot : null); ?>


        <?php echo $__env->make('layouts.layout-landing.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php echo $__env->make('layouts.layout-landing.js', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldPushContent('script-custom'); ?>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\MSIB_Kelompok_7\MSIB_Laravel_Projek\resources\views/content-landing/index.blade.php ENDPATH**/ ?>