<?php $__env->startPush('style-custom'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
<?php $__env->stopPush(); ?>
<?php $__env->startSection('isi-contentAdmin'); ?>
    <div class="card p-3">
        <h5 class="card-header">Data Vaksin</h5>
        <div class="card-body">
            <button type="button" class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#tambah">+ Tambah
                Data</button>
            <?php echo $__env->make('content-admin.vaksinasi.vaksinasi-tambah', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="table-responsive text-nowrap">
                <table id="datatable1" class="table">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Nama</th>
                            <th>Jenis Vaksin</th>
                            <th>Dosis</th>
                            <th>Tanggal Vaksin</th>
                            <th>Keterangan</th>
                            <th>Opsi</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        <?php $__currentLoopData = $data_vaksinasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><strong><?= $loop->iteration ?></strong></td>
                                <td><?php echo e($d->pendudukFk->nama); ?></td>
                                <td><?php echo e($d->jenisVaksinFk->nama_vaksin); ?></td>
                                <td><?php echo e($d->dosisFk->nama_dosis); ?></td>
                                <td><?php echo e($d->tgl_vaksin); ?></td>
                                <td><?php echo e($d->keterangan); ?></td>
                                </td>
                                <td>
                                    <div class="d-flex">
                                        <button type="button" class="btn btn-sm btn-info" data-bs-toggle="modal"
                                            data-bs-target="#detail<?php echo e($d->id); ?>">
                                            <i class="bx bx-edit-alt me-1"></i>
                                        </button>
                                        <?php echo $__env->make('content-admin.vaksinasi.vaksinasi-edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                        &nbsp;
                                        <form method="POST" action="<?php echo e(route('admin-vaksinasiHapus', $d->id)); ?>">
                                            <?php echo csrf_field(); ?>
                                            <button class="btn btn-sm btn-danger" type="submit" name="proses"
                                                value="hapus" onclick="return confirm('Anda Yakin Data dihapus?')"><i
                                                    class="bx bx-trash me-1"></i>
                                            </button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('script-custom'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $("input[name~='nik']").keyup(function() {
                var nikk = $(this).val()
                loadJenisVaksin(nikk)
            });

            function loadJenisVaksin(nikk) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo e(route('admin-getJenisVaksin')); ?>",
                    data: {
                        nik: nikk
                    },
                    success: function(data) {
                        if (data == 0) {
                            document.getElementById("dosis").innerHTML = ''
                            console.log(data);
                        } else {
                            var dataDosis = ''
                            for (const d in data) {
                                dataDosis +=
                                    `<option value="${data[d].id}">${data[d].nama_dosis}</option>`;
                            }
                            document.getElementById("dosis").innerHTML = dataDosis
                            // console.log(dataDosis);
                        }
                    }
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('content-admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MSIB_Kelompok_7\MSIB_Laravel_Projek\resources\views/content-admin/vaksinasi/vaksinasi.blade.php ENDPATH**/ ?>