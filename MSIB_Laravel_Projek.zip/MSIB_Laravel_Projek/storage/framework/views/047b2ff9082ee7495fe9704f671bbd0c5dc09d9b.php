<?php echo e($data); ?>

<?php /**PATH C:\xampp\htdocs\MSIB_Laravel_Projek\resources\views/content-landing/home.blade.php ENDPATH**/ ?>