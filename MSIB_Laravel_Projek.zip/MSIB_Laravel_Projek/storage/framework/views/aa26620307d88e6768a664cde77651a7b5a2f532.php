<?php $__env->startSection('isi-content'); ?>
    <h1>Ini Beranda Admin</h1>
    <?php echo e($data); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout-admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\MSIB_Laravel_Projek\resources\views/content-admin/home.blade.php ENDPATH**/ ?>